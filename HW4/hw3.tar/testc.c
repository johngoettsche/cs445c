typedef struct{
	int x;
}y;

int main(){
   y z;
}
