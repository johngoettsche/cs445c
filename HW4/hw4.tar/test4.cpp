int main(int a){
	if(a > 5) a = 7;
	else a++;
	return a;
}