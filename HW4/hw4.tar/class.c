
class testClass{
	private :
		int x;
	public :
		testClass();
		~testClass();
};

testClass::testClass(){
}

testClass::~testClass(){
}