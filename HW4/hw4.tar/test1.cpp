int main(){
	int a = 3;
	while (a < 10) {
		a++;
		if(a % 2 = 0) break;
	}
	return 10;
}