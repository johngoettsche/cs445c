/*
 * John Goettsche
 * CS445
 *
 * codegen.h 
 */


/* prototypes */
int getBits(NType *symb, int bits);
void calculateOffsets(SymbolTable *symbolTable);