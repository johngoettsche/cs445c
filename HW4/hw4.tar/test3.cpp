#include <iostream>
using namespace std;

int main(){
	int a = 0;
	for(int i = 0; i < 5; i++){
		a += i;
	}
	return 1;
}