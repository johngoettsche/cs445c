int main(){
	int a = 3;
	do {
		a++;
	} while( a < 10);
	return 10;
}